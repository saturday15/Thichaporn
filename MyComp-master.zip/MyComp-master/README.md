# MyComp

![screentshot](https://image.prntscr.com/image/KON1l7XoQL_RKpFuhWxYlQ.png)

ไฟล์ประกอบการเรียนการสอน HTML CSS โดย ปฏิภาณ เพ็งเภา | MilerDev 

Youtube : https://www.youtube.com/channel/UCeKE6wQHTt5JpS9_RsH4hrg?view_as=subscriber

Tutorial files for learning html and css by patiphan (miler)
